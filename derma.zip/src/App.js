import React from "react";
import "./App.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Header from "./Assets/Components/Header/Header";
import Footer from "./Assets/Components/Footer/Footer";

import Forside from "./Assets/Pages/Forside/Forside";

function App() {
  return (
    <div className="App">
      <Router>
        <Header />
        <Switch>
          <Route path="/" exact component={Forside} />
        </Switch>
        <Footer />
      </Router>
    </div>
  );
}

export default App;

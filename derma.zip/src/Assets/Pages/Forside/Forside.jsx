import React from "react";

import Welcome from "../../Components/Welcome/Welcome";
import Adtralza from "../../Components/Adtralza/Adtralza";
import Threelinks from "../../Components/Threelinks/Threelinks";
import Videomodal from "../../Components/Videomodal/Videomodal";
import Clinical from "../../Components/Clinical/Clinical";
import KOL from "../../Components/KOL/KOL";
import References from "../../Components/References/References";



const Forside = () => {
  return (
    <div>
      <Welcome />
      <Adtralza />
      <Threelinks />
      <Videomodal/>
      <Clinical/>
      <KOL/>
      <References/>
    </div>
  );
};

export default Forside;

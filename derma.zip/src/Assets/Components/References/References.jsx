import React from 'react'
import "./References.css"
import {MdOutlineKeyboardArrowDown} from "react-icons/md"

const References = () => {
    return (
        <div className="references__main">
            <div className="references__container">
            <div className="references__circle"><MdOutlineKeyboardArrowDown size="4rem" className="reference__arrow"/></div>
            <h1>References</h1>
            </div>
        </div>
    )
}

export default References

import React from 'react'
import "./Footer.css"
import { NavLink } from "react-router-dom";


const Footer = () => {
    return (
        <div className="footer__main">

            <div className="footer__logo">
                <img src="./img/Footer/leo-logo.png" alt="" />
            </div>

            <div className="footer__copyrights">
                <p>© Copyright LEO Pharma 2020 <br /> LEO and the LEO Lion Design <br /> are registered trademarks <br /> of LEO Pharma <br /> All rights reserved</p>
            </div>

            <div className="clearboth"></div>
            <div className="footer__corporate">
                <NavLink className="footer__corporate__nl" to="/">LEO Pharma corporate website</NavLink>
            </div>
            <div className="footer__links">
                <NavLink className="footer__links__nl" to="/">Contact</NavLink>
                <NavLink className="footer__links__nl" to="/">Imprint</NavLink>
                <NavLink className="footer__links__nl" to="/">Conditions</NavLink>
                <NavLink className="footer__links__nl" to="/">Terms of Use</NavLink>
                <NavLink className="footer__links__nl" to="/">Privacy</NavLink>
                <NavLink className="footer__links__nl" to="/">Cookie Content</NavLink>

            </div>




        </div>
    )
}

export default Footer

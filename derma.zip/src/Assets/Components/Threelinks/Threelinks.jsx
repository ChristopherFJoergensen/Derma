import React from "react";
import "./Threelinks.css";
import Data from "../../../Data.json";
import { NavLink } from "react-router-dom";

const Threelinks = () => {
  return (
    <div className="threelinks__main">
      {Data.Threelinks.map((item, key) => (
        <div className="main__item" key={key}>
          <img src={"./img/Threelinks/" + item.image} alt="" />
          <h2>{item.title}</h2>
          <p>{item.text}</p>
          <NavLink className="main__link" to="/">{item.link}</NavLink>
        </div>
      ))}
    </div>
  );
};

export default Threelinks;

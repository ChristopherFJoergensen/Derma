import React from 'react'
import "./KOL.css"
import Data from "../../../Data.json"

const KOL = () => {
    return (
        <div className="KOL__main">
            <div className="KOL__container">
                <h1 className="KOL__h1">KOL videos - get expert insights here</h1>
                <p>See what Key opinion leaders have to say about heir experiences with Adtralza®</p>
                <div className="KOL__flex">
                    {Data.KOL.map((item, key) => (
                        <div className="KOL__card" key={key}>
                            <div className="KOL__card__image">
                                <img src={"./img/KOL/" + item.image} alt="" />
                            </div>
                            <div className="KOL__card__text">
                                <h4>{item.title}</h4>
                                <p>{item.text}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

export default KOL

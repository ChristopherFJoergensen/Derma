import React from 'react'
import "./Videomodal.css"
import Data from "../../../Data.json"


const Videomodal = () => {
    return (
        <div className="modal__main">


            {Data.Videomodal.map((item, key) => (
                <div className="modal__container" key={key}>
                    <div className="modal__container__left">
                        <h1>{item.title}</h1>
                        <p className="container__left__text">{item.text1}</p>
                        <p className="container__left__text">{item.text2}</p>
                        <p className="container__left__text">{item.text3}</p>
                        <p>{item.text4}</p>
                        <p>{item.text5}</p>
                        <button className="">Watch the video</button>
                        <p>Duration: 2:43</p>
                    </div>
                    <div className="modal__container__right">
                        <img src={"./img/Videomodal/" + item.image} alt="" />
                    </div>
                </div>
            ))}
        </div>
    )
}

export default Videomodal

import React from 'react'
import "./Clinical.css"
import Data from "../../../Data.json"
import { NavLink } from "react-router-dom";


const Clinical = () => {
    return (
        <div>
            <div className="clinical__container">
                <div className="clinical__title">
                    <h1>Clinical tools - at a glance</h1>
                </div>
                <div className="clinical__main">
                    {Data.Clinical.map((item, key) => (

                        <div className="clinical__card" key={key}>
                            <img src={"./img/Clinical/" + item.image} alt="" />
                            <div className="card__text">
                                <h1>{item.title}</h1> 
                                <br />
                                <p>{item.text}</p>
                                <br />

                                <NavLink className="card__link" to="/">{item.link}</NavLink>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

export default Clinical

import React from 'react'
import "./Adtralza.css"
import Data from "../../../Data.json"

const Adtralza = () => {
    return (
        <div className="adtralza__main">
            {Data.Adtralza.map((item, key) => (
                <div key={key}>
                <div className="main__img">
                <img src={"./img/Adtralza/" + item.image} alt="" />
                </div>
                <div className="main__text"> 

                <h1>{item.title}</h1>
                <br />
                <p>{item.text}</p>
                </div>
                </div>
            ))}
        </div>
    )
}

export default Adtralza

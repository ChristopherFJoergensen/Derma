import React from 'react'
import "./Welcome.css"
import Data from "../../../Data.json"

const Welcome = () => {
    return (
        <div className="welcome__main">
        <img className="banner__background" src="./img/Welcome/banner-image-background.jpg" alt="" />
            {Data.Welcome.map((item, key) => (
                <div key={key} className="welcome__main__textcontainer">
                <img src={"./img/Welcome/" + item.image} alt="" />
                <h1>{item.text}</h1>
                </div>
            ))}  
            <div className="welcome__main__rightpeople">
            <img src="./img/Welcome/banner-image-transparent.png" alt="" />
            </div>
        </div>
    )
}

export default Welcome

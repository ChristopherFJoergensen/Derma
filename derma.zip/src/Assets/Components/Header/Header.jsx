import React from "react";
import "./Header.css";
import { NavLink } from "react-router-dom";
import { AiOutlineSearch } from "react-icons/ai";

const Header = () => {
  return (
    <div className="header__main">
      <section className="main__logo">
        <NavLink className="logo__navlink" to="/">
          <p>
            <strong>DERMA</strong>
          </p>
          <p className="logo__worldtext">World</p>
          <br />
          <p className="logo__leotext">
            By <strong>LEO Pharma</strong>
          </p>
        </NavLink>
      </section>
      <div className="main__searchbar">
        <AiOutlineSearch className="searchbar__searchicon" />
        <input placeholder="Search" type="text" />
      </div>

      <div className="header__nav">
        <nav>

          <ul className="header__row1">
            <li><a href=".">Bedingungen</a></li>
            <li><a className="show__adtralza" href=".">Behundlungen</a></li>
            <li><a href=".">Veranstaltungen</a></li>
            <li><a href=".">Werkzeuge</a></li>
            <li><a href=".">Forschung und Erkenntnisse</a></li>
          </ul>

          <div className="clearboth"></div>

          <ul className="header__row2">
            <li><a href=".">Bedingungen</a></li>
            <li><a href=".">Behundlungen</a></li>
            <li><a href=".">Veranstaltungen</a></li>
            <li><a href=".">Werkzeuge</a></li>
            <li><a href=".">Forschung und Erkenntnisse</a></li>
          </ul>

          <div className="clearboth"></div>

          <ul className="header__row3">
            <li><a href=".">Bedingungen</a></li>
            <li><a href=".">Behundlungen</a></li>
            <li><a href=".">Veranstaltungen</a></li>
            <li><a href=".">Werkzeuge</a></li>
            <li><a href=".">Forschung und Erkenntnisse</a></li>
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default Header;
